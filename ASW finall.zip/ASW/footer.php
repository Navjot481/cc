<!-- Footer section -->
<footer class="footer-section">
    <div class="container">
        <div class="row">
            <!-- widget -->
            <div class="col-sm-6 col-lg-3">
                <div class="about-widget">
                    <img src="img/logo.png" alt="">
                    <p>University Support Website.</p>
                    <div class="social pt-1">

                    </div>
                </div>
            </div>
            <!-- widget -->
            <div class="col-sm-6 col-lg-3 footer-widget">
                <h6 class="fw-title">USEFUL LINK</h6>
                <div class="dobule-link">
                    <ul>
                        <li><a href="">Home</a></li>
                        <li><a href="">About us</a></li>
                        <li><a href="">Services</a></li>

                    </ul>
                    <ul>
                        <li><a href="">Policy</a></li>
                        <li><a href="">Term</a></li>
                        <li><a href="">Help</a></li>

                    </ul>
                </div>
            </div>
            <!-- widget -->
            <div class="col-sm-6 col-lg-3 footer-widget">
                <h6 class="fw-title">RECENT POST</h6>
                <ul class="recent-post">
                    <li>
                        <p>Snackable study:How to break <br> up your master's degree</p>
                        <span><i class="fa fa-clock-o"></i>24 Mar 2020</span>
                    </li>
                    <li>

                    </li>
                </ul>
            </div>
            <!-- widget -->
            <div class="col-sm-6 col-lg-3 footer-widget">
                <h6 class="fw-title">CONTACT</h6>
                <ul class="contact">
                
                    <li><p><i class="fa fa-phone"></i> (+88) 111 555 666</p></li>
                    <li><p><i class="fa fa-envelope"></i> infodeercreative@gmail.com</p></li>
                    <li><p><i class="fa fa-clock-o"></i> Monday - Friday, 08:00AM - 06:00 PM</p></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- copyright -->
    <div class="copyright">
<!--        <div class="container">-->
            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved
                <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
<!--        </div>-->
    </div>
</footer>
<!-- Footer section end-->



<!--====== Javascripts & Jquery ======-->
<script src="js/jquery-3.2.1.min.js"></script>
<script src="dist/jquery.validate.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.countdown.js"></script>
<script src="js/masonry.pkgd.min.js"></script>
<script src="js/magnific-popup.min.js"></script>
<script src="js/main.js"></script>