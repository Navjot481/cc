<?php
session_start();
if (!isset($_SESSION["Admin_Email"])) {
    header("location:adminlogin.php");
}
$email = $_POST["email"];
$oldpassword = md5($_POST["oldpassword"]);
$newpassword = md5($_POST["newpassword"]);
include_once "connection.php";
$select = "select * from admin where Email='$email' and Password='$oldpassword'";
//echo $select;
$data = mysqli_query($con, $select);
if (mysqli_num_rows($data) > 0) {

    $update = "update admin set Password='$newpassword' where Email='$email'";
    if (mysqli_query($con, $update)) {

        header("location:admin_changePassword.php?msg=1");
    }

} else {
    header("location:admin_changePassword.php?msg=0");
}