<?php
session_start();
?>
    <!doctype html>
    <html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php
    include_once "headerfiles.php";
    ?>
</head>
<body>
<?php
include_once "studentheader.php";

?>

<div class="container">
    <br>
    <br>
    <div class="row justify-content-around">
        <?php
        echo "<h2> welcome  to Student Panel</h2>";
        ?>
    </div>
    <br>
    <br>
</div>
<?php
include_once "footer.php";
?>
</body>
    </html><?php
