<?php
session_start();
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php
    include "headerfiles.php";
    ?>
</head>
<body>
<?php
include "connection.php";
$email = $_GET["email"];
$selectcommand = "select * from Admin where Email ='$email'";
$result = mysqli_query($con, $selectcommand);
$row = mysqli_fetch_array($result);
include "adminheader.php";
?>
<div class="container">
    <h1 class="text-center">EDIT ADMIN</h1>
    <div class="row">
        <div class="col-sm-6 offset-sm-3">
            <form action="updateadmin.php" method="post">
                <div class="form-group">
                    <label for="email">Email</label>

                    <input type="text" readonly name="email"
                           value="<?php echo $row[0]; ?>"
                           class="form-control" id="email">

                </div>
                <div class="form-group">
                    <label for="mobileno">Mobile No</label>

                    <input type="text" name="mobileno"
                           value="<?php echo $row[2]; ?>"
                           id="mobileno" class="form-control">

                </div>

                <div class="form-group">
                    <label for="type">Type</label>

                    <select name="type" id="type" class="form-control">
                        <option> select type</option>

                        <option value="Admin" <?php if ($row[3] == 'Admin') {
                            echo 'selected';
                        } ?>>ADMIN
                        </option>
                        <option value="SUBADMIN" <?php if ($row[3] == 'SUBADMIN') {
                            echo 'selected';
                        } ?>>SUBADMIN
                        </option>
                    </select>

                </div>

                <div class="form-group">

                    <input type="submit" value="UPDATE" class="btn btn-block btn-primary"></div>

            </form>
            <?php
            if (isset($_REQUEST["msg"])) {
                if ($_REQUEST["msg"] == 2) {
                    echo '<div class="alert alert-danger">Data Not Updated</div>';
                }
            }
            ?>
        </div>
    </div>
</div>
<?php
include "footer.php";
?>

</body>
</html>




