<?php
session_start();
if (!isset($_SESSION["Admin_Email"])) {
    header("location:adminlogin.php");
}else {
    require_once("class.phpmailer.php");
    include_once "connection.php";
    function randomPassword()
    {
        $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!@#$%&*(';
        $pass = array(); //remember to declare $pass as an array
        $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
        for ($i = 0; $i < 8; $i++) {
            $n = rand(0, $alphaLength);
            $pass[] = $alphabet[$n];
        }
        return implode($pass); //turn the array into a string
    }

    if ($_POST["action"] == "new") {
        $name = $_POST["name"];
        $email = $_POST["email"];
        $programmercode = $_POST["programmercode"];
        $semester = $_POST["semester"];
        $password = randomPassword();
        $en_password = md5($password);
        $Query = "INSERT INTO `students`(`Studentid`, `Name`, `Email`, `Password`, `programcode`, `semester`) 
VALUES (null,'$name','$email','$en_password','$programmercode','$semester')";
        echo $Query;
        if (mysqli_query($con, $Query)) {
            $id = mysqli_insert_id($con);
//        error_reporting(E_STRICT);
            date_default_timezone_set('Asia/Kolkata');
            //  $email=$_POST["email"];
            $subject = "Congratulation $name ,you are registered with us   ";
            $body = "Congratulation $name you are registered with us , your login id is $id and password is $password ";
            $mail = new PHPMailer();
            $mail->IsSMTP(); // telling the class to use SMTP
            $mail->SMTPDebug = 1;                     // enables SMTP debug information (for testing)
            $mail->SMTPAuth = true;                  // enable SMTP authentication
            $mail->SMTPSecure = "ssl";                 // sets the prefix to the servier
            $mail->Host = "smtp.gmail.com";      // sets GMAIL as the SMTP server
            $mail->Port = 465;                   // set the SMTP port for the GMAIL server
            $mail->Username = "studentsdemo20@gmail.com";  // GMAIL username
            $mail->Password = "Temp@123";            // GMAIL password
            $mail->SetFrom('studentsdemo20@gmail.com', 'USW');
            $mail->AddReplyTo("studentsdemo20@gmail.com", "USW");
            $mail->Subject = $subject;
            $mail->AltBody = "To view the message, please use an HTML compatible email viewer!"; // optional, comment out and test
            $mail->MsgHTML($body);
            $address = $email;
            $mail->AddAddress($address, "");
            if (!$mail->Send()) {
                echo "Mailer Error: " . $mail->ErrorInfo;
                header("location:addstudent.php?msg=emailfailed");

            } else {
                header("location:addstudent.php?msg=success");
            }


        }


    } else {
        header("location:addstudent.php?msg=failed");
    }
}