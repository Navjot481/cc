<?php
session_start();
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php
    include"headerfiles.php";
    ?>
</head>
<body>
<?php
include"adminheader.php";
?>
<h1 class="text-center">VIEW ADMIN</h1>
<div class="container">
    <table class="table table-bordered table-hover">
        <th>Email</th>
        <th>Mobile No</th>

        <th>Type</th>
        <th colspan="2">  Operations</th>
        <?php
        include"connection.php";
        $select="select * from Admin";
        $result=mysqli_query($con,$select);
        while($row=mysqli_fetch_array($result))
        {
            echo"<tr>";
            echo"<td>$row[0]</td>";
            echo"<td>$row[2]</td>";
            echo"<td>$row[3]</td>";

            echo"<td><a href='deleteadmin.php?email=$row[0]' onclick='return confirm(\"Are you sure to delete??\")'>Delete</a></td>";
            echo"<td><a href='editadmin.php?email=$row[0]'>Edit</a></td>";
            echo"</tr>";
        }
        ?>
    </table>
</div>
<?php
include("footer.php");
?>
</body>
</html>
