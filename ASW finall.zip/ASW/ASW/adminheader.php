<?php

/* isset function is used to check if the session is created or not ,
 if not then redirect to admin login page, in this way we can secure pages from anuthorized access */
if (!isset($_SESSION["Admin_Email"])) {
    header("location:adminlogin.php");
}
?>

    <style>
        body {
            /*padding-top: 100px;*/
        }
    </style>

    <!-- Page Preloder -->
    <div id="preloder">
        <div class="loader"></div>
    </div>

    <!-- header section -->
    <header class="header-section">
        <div class="container">
            <!-- logo -->
            <a href="index.php" class="site-logo"><img src="img/logo.png" alt=""></a>
            <div class="nav-switch">
                <i class="fa fa-bars"></i>
            </div>
            <div class="header-info">
                <div class="hf-item">
                    <i class="fa fa-clock-o"></i>
                    <p><span>Working time:</span>Monday - Friday: 08 AM - 06 PM</p>
                </div>
                <div class="hf-item">
                    <i class="fa fa-map-marker"></i>
                    <p><span>Find us:</span>40 Baria Street 133/2, New York City, US</p>
                </div>
            </div>
        </div>
    </header>
    <!-- header section end-->


    <!-- Header section  -->
    <nav class="nav-section">
        <div class="container">
            <div class="nav-right">
                <!--                <a href=""><i class="fa fa-search"></i></a>-->
                <!--                <a href=""><i class="fa fa-shopping-cart"></i></a>-->
            </div>
            <ul class="main-menu">
                <li class="nav-item"><a class="nav-link" href="adminhome.php">Home</a></li>

                <li class="nav-item ">

                    <a href="addadmin.php" class="nav-link">Add Admin</a></li>
                <li class="nav-item ">
                    <a href="viewadmin.php" class="nav-link">View Admin</a>

                </li>
                <li class="nav-item ">


                    <a href="addstudent.php" class="nav-link">Add Students</a></li>
                <li class="nav-item "><a href="viewstudents.php" class="nav-link">View Students</a>

                </li>

                <li class="nav-item"><a class="nav-link" href="admin_changePassword.php">Change Password</a></li>
                <li class="nav-item"><a onclick="return confirm('Are you sure to Exit ?')" class="nav-link"
                                        href="logout.php">Logout</a></li>
            </ul>
        </div>
    </nav>
    <!-- Header section end -->


<?php
