<?php
session_start();
if (!isset($_SESSION["Student_Session"])) {
    header("location:studentlogin.php");
}
$sid = $_POST["id"];
$oldpassword = md5($_POST["oldpassword"]);
$newpassword = md5($_POST["newpassword"]);
include_once "connection.php";
$select = "select * from students where Studentid='$sid' and Password='$oldpassword'";
//echo $select;
$data = mysqli_query($con, $select);
if (mysqli_num_rows($data) > 0) {

    $update = "update students set Password='$newpassword' where Studentid='$sid'";
    if (mysqli_query($con, $update)) {

        header("location:student_changePassword.php?msg=1");
    }

} else {
    header("location:student_changePassword.php?msg=0");
}