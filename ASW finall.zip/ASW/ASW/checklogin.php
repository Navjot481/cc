<?php
session_start();
//
$email = $_POST["email"];
$password = md5($_POST["password"]);
//md5 encryption is ued to encrypt password
include_once "connection.php";
$select = "select * from `Admin` where Email='$email' and Password='$password'";
$data = mysqli_query($con, $select);
if (mysqli_num_rows($data) > 0) {
    $row = mysqli_fetch_array($data);
    $_SESSION["Admin_Email"] = $email;
       //echo "success";
    header("location:adminhome.php");
} else {
//    echo "failed";
    header("location:adminlogin.php?msg=1");
}