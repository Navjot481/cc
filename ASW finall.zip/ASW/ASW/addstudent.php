<?php
session_start();
?>
<!doctype html>
<html lang="en" xmlns:style-color="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php
    include "headerfiles.php";
    ?>
</head>
<body>
<?php
include "adminheader.php";
?>
<div class="container">
    <h2 class="text-center">ADD STUDENT</h2>
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <form action="studentaction.php" method="post" id="form1">
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" name="name"
                           data-rule-required="true"

                           data-msg-required="enter name"
                           id="name" class="form-control"/>
                </div>
                <div class="form-group">
                    <label for="email">EMAIL</label>
                    <input type="email" name="email"
                           data-rule-required="true"
                           data-msg-reqiured="enter email"
                           class="form-control" id="email"/>
                </div>


                <div class="form-group">
                    <label for="type">Programmercode</label>
                    <select name="programmercode" id="programmercode" class="form-control"    data-rule-required="true">
                        <option value=""> select Programmercode</option>
                        <?php
                        include_once "connection.php";
                        $selectcode = "SELECT * FROM `programs` ";
                        $resultcode = mysqli_query($con, $selectcode);
                        while ($rowcode = mysqli_fetch_array($resultcode)) {
                            ?>
                            <option value="<?php echo $rowcode[0]; ?>"><?php echo $rowcode[0]; ?></option>
                            <?php
                        }
                        ?>

                    </select>
                </div>
                <div class="form-group">
                    <label for="semester">Semester</label>
                    <select name="semester" id="semester" class="form-control"    data-rule-required="true">
                        <option value=""> select semester</option>
                        <option> Semester-1</option>
                        <option> Semester-2</option>
                        <option> Semester-3</option>
                        <option> Semester-4</option>


                    </select>
                </div>
                <div class="form-group">
                    <input type="hidden" name="action" value="new">
                    <input type="submit" value="Create Admin" class="btn btn-primary">
                    <?php
                    if (isset($_GET["msg"])) {
                        if ($_GET["msg"] == "success") {
                            echo "<div class='alert alert-success'>Student addedd Successfully</div>";
                        } elseif ($_GET["msg"] == "emailfailed") {
                            echo "<div class='alert alert-warning'>Student Added but couldn't sent email</div>";
                        }else{
                            echo "<div class='alert alert-danger'></div>";
                        }
                    }
                    ?>
                </div>


            </form>
        </div>
    </div>

</div>


<?php
include "footer.php";

?>
<script>
    $(document).ready(function () {
        $("#form1").validate();
    })
</script>
</body>
</html>