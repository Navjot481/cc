<?php
session_start();
$id = $_POST["sid"];
$password = md5($_POST["password"]);
//md5 encryption is ued to encrypt password
include_once "connection.php";
$select = "select * from `students` where Studentid='$id' and Password='$password'";

echo "543aa5a15f4e1fb975f299c81cf63ff7  ="." $password";
$data = mysqli_query($con, $select);
if (mysqli_num_rows($data) > 0) {
    $row = mysqli_fetch_array($data);
    $_SESSION["Student_Session"] = $id;
    //echo "success";
    header("location:studenthome.php");
} else {
//    echo "failed";
    header("location:studentlogin.php?msg=1");
}