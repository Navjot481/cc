<?php
error_reporting(0);
$con=mysqli_connect("localhost","root",null,"ASW");
if(!$con)
{
    die( "connection failed due to ".mysqli_connect_error());
}

