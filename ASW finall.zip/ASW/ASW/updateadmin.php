<?php
include"connection.php";
$email=$_POST["email"];
$username=$_POST["username"];
$mobileno=$_POST["mobileno"];
$type=$_POST["type"];
$query="update admin set Mobilenumber='$mobileno',`Type`='$type' where Email='$email'";
if(mysqli_query($con,$query))
{
    header("location:viewadmin.php");
}
else
{
//    echo  $query;
    header("location:editadmin.php?msg=2&email=$email");
}