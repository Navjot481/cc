<?php
require_once "Cart.php";
require_once('class.phpmailer.php');
include_once "connection.php";

session_start();

$cartArray = array();
if (isset($_SESSION["Cart"])) {
    $cartArray = $_SESSION["Cart"];
}
date_default_timezone_set("Asia/Kolkata");
$orderdate = date("Y-m-d");
$ordertype = $_SESSION["ordertype"];
$email = $_SESSION["useremail"];
$payment = 'paid';
if ($ordertype == "COD") {
    $payment = "Pending";
}

$amount = 0;
for ($i = 0; $i < count($cartArray); $i++) {
    $amount += $cartArray[$i]->qty * ($cartArray[$i]->price - ($cartArray[$i]->price * ($cartArray[$i]->discount / 100)));
}

$orders = "INSERT INTO `orders`(`orderdate`, `orderby`, `totalamount`, `orderstatus`, `paymentstatus`, `ordertype`) VALUES ('$orderdate','$email','$amount','placed','$payment','$ordertype')";
if (mysqli_query($con, $orders)) {

    $orderid = mysqli_insert_id($con);

    for ($i = 0; $i < count($cartArray); $i++) {
        $productid = $cartArray[$i]->productid;
        $price = $cartArray[$i]->price;
        $discount = $cartArray[$i]->discount;
        $qty = $cartArray[$i]->qty;
        $orderdetails = "INSERT INTO `orderdetails`( `orderid`, `productid`, `price`, `discount`, `qty`)
 VALUES ($orderid,$productid,$price,$discount,$qty)";
        mysqli_query($con, $orderdetails);


    }


//include("class.smtp.php"); // optional, gets called from within class.phpmailer.php if not already loaded



    $mail = new PHPMailer();

    /*$body             = file_get_contents('contents.html');
    $body             = preg_replace('/[\]/','',$body);*/

    $mail->IsSMTP(); // telling the class to use SMTP
//$mail->Host = "mail.yourdomain.com"; // SMTP server
    $mail->SMTPDebug = 1;                     // enables SMTP debug information (for testing)
// 1 = messages only
// 2 =  errors and messages
    $mail->SMTPAuth = true;                  // enable SMTP authentication
    $mail->SMTPSecure = "ssl";                 // sets the prefix to the servier
    $mail->Host = "smtp.gmail.com";      // sets GMAIL as the SMTP server
    $mail->Port = 465;                   // set the SMTP port for the GMAIL server
    $mail->Username = "vmmstudents2020@gmail.com";  // GMAIL username
    $mail->Password = "Temp@1234";            // GMAIL password

    $mail->SetFrom('vmmstudents2020@gmail.com', 'VMM EDUCATION');

    $mail->AddReplyTo("vmmstudents2020@gmail.com", "VMM EDUCATION");

    $mail->Subject = "Order Confirmation from Demo Shopping";

    $mail->AltBody = "To view the message, please use an HTML compatible email viewer!"; // optional, comment out and test
    $body = " dear " . $_SESSION["user_name"] . ",<br> Your order has been placed successfully, thank you for shopping with us";
    $mail->MsgHTML($body);

    $address = $email;

    $mail->AddAddress($address, "");


//$mail->AddAddress("singh.parwinder01@gmail.com", "Parwinder");

    /*$mail->AddAttachment("images/phpmailer.gif");      // attachment
    $mail->AddAttachment("images/phpmailer_mini.gif"); */// attachment

    if (!$mail->Send()) {
        echo "Mailer Error: " . $mail->ErrorInfo;

    } else {
        echo "success";
    }


    unset($_SESSION["ordertype"]);
    unset($_SESSION["Cart"]);
    echo "order placed";
}


