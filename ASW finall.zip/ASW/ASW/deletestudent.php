<?php
session_start();
if (!isset($_SESSION["Admin_Email"])) {
    header("location:adminlogin.php");
}else {
    $id = $_GET["id"];
    include "connection.php";
    $deletequery = "delete from students where Studentid='$id'";
    if (mysqli_query($con, $deletequery)) {
        header("location:viewstudents.php");
    } else {
        echo "unable to delete record";
    }
}