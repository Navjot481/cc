<?php
session_start();
if (!isset($_SESSION["Admin_Email"])) {
    header("location:adminlogin.php");
}else {
    $email = $_GET["email"];
    include "connection.php";
    $deletequery = "delete from admin where Email='$email'";
    if (mysqli_query($con, $deletequery)) {
        header("location:viewadmin.php");
    } else {
        echo "unable to delete record";
    }
}