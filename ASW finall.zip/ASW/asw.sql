-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2020 at 03:04 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `asw`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Email` varchar(60) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `Mobilenumber` varchar(10) NOT NULL,
  `Type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Email`, `Password`, `Mobilenumber`, `Type`) VALUES
('', 'd41d8cd98f00b204e9800998ecf8427e', '', ''),
('cs@demo.com', 'e10adc3949ba59abbe56e057f20f883e', '874563201', 'Admin'),
('demo@demo.com', '827ccb0eea8a706c4c34a16891f84e7b', '8978979879', 'Admin'),
('info@demo.com', 'e10adc3949ba59abbe56e057f20f883e', '7896548888', 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `Deptid` int(11) NOT NULL,
  `Dname` varchar(100) NOT NULL,
  `Description` varchar(300) NOT NULL,
  `coverphoto` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`Deptid`, `Dname`, `Description`, `coverphoto`) VALUES
(1, 'Computer Science and Engineering', 'The Department runs a four-year B.Tech. programme in Computer Science and Engineering', ''),
(4, 'Physics Department', 'This Department offers a four – Semester M. Sc. programme (Two years duration) where the students at present can opt for one of the two specializations – i) Astrophysics and ii) Condensed Matter Physics, with laboratory classes.', '');

-- --------------------------------------------------------

--
-- Table structure for table `programs`
--

CREATE TABLE `programs` (
  `Programcode` varchar(20) NOT NULL,
  `Title` varchar(100) NOT NULL,
  `Description` varchar(200) NOT NULL,
  `Semesters` varchar(20) NOT NULL,
  `programobjective` varchar(200) NOT NULL,
  `Deptid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `programs`
--

INSERT INTO `programs` (`Programcode`, `Title`, `Description`, `Semesters`, `programobjective`, `Deptid`) VALUES
('MSC-AST', 'M.Sc.- Astrophysics', 'M.Sc.- Astrophysics', 'Sem-1', '', 4),
('MSC-CMP', 'M.Sc.- Condensed Matter Physics', 'M.Sc.- Astrophysics', 'Sem-1', '', 4);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `Studentid` int(11) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `programcode` varchar(20) NOT NULL,
  `semester` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`Studentid`, `Name`, `Email`, `Password`, `programcode`, `semester`) VALUES
(13, 'parwinder singh', 'parwindersingh@vmmeducation.com', '827ccb0eea8a706c4c34a16891f84e7b', 'MSC-CMP', 'Semester-1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Email`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`Deptid`);

--
-- Indexes for table `programs`
--
ALTER TABLE `programs`
  ADD PRIMARY KEY (`Programcode`),
  ADD KEY `Deptid` (`Deptid`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`Studentid`),
  ADD KEY `programcode` (`programcode`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `Deptid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `Studentid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `programs`
--
ALTER TABLE `programs`
  ADD CONSTRAINT `programs_ibfk_1` FOREIGN KEY (`Deptid`) REFERENCES `departments` (`Deptid`);

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`programcode`) REFERENCES `programs` (`Programcode`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
