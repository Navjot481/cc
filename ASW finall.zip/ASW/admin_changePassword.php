<?php
session_start();
?><!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php
    include_once "headerfiles.php";
    ?>

    <script>
        $(document).ready(function () {
            $("#form1").validate();
        })
    </script>
</head>
<body>
<?php
include_once "adminheader.php";

?>

<div class="container">
    <div class="row">
        <div class="col-sm-8 offset-sm-2">
            <h1 class="text-center">Admin Change Password</h1>
            <form action="adminupdatepassword.php" method="post" id="form1">
                <div class="form-group row">
                    <label for="email" class="col-sm-4">Email</label>
                    <div class="col-sm-8">
                    <input type="text" data-rule-required="true" class="form-control " name="email"  value="<?php echo $_SESSION['Admin_Email']; ?>" id="email" readonly>

                    </div>
                </div>
                <div class="form-group row">
                    <label for="oldpassword" class="col-sm-4">Current Password</label>
                    <div class="col-sm-8">
                    <input type="password" data-rule-required="true" class="form-control" name="oldpassword" id="oldpassword">
                    </div>
                </div>

                <div class="form-group row">
                    <label for="newpassword" class="col-sm-4">New Password</label>
                    <div class="col-sm-8">
                    <input type="password" data-rule-required="true" class="form-control" name="newpassword" id="newpassword">
                    </div>

                </div>
                <div class="form-group row">
                    <label for="conpassword" class="col-sm-4">Confirm New Password</label>
                    <div class="col-sm-8">
                    <input type="password" data-rule-required="true" data-rule-equalto="#newpassword" class="form-control" name="conpassword" id="conpassword">
                    </div>
                </div>
                <div class="form-group">
                    <div class="offset-sm-4">
                        <button class="btn btn-primary" type="submit">Update Password</button>
                        <a href="adminhome.php" class="btn btn-warning">Cancel</a>
                    </div>

                    <?php
                    if (isset($_GET["msg"])) {
                        if ($_GET["msg"] == 0) {
                            echo "<div class='alert alert-danger'>Invalid Old Password</div>";
                        }else{
                            echo "<div class='alert alert-success'>Password Changed</div>";
                        }
                    }
                    ?>
                </div>
            </form>
        </div>
    </div>


</div>
<?php
include_once "footer.php";
?>
</body>
</html>