<?php
session_start();
?>
<!doctype html>
<html lang="en" xmlns:style-color="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php
    include "headerfiles.php";
    ?>
</head>
<body>
<?php
include "adminheader.php";
?>
<div class="container">
    <h1 class="text-center" >ADD ADMIN</h1>
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <form action="addadminaction.php" method="post" id="form1">
                <div class="form-group">
                    <label for="email" >EMAIL</label>

                    <input type="text" name="email"
                           data-rule-required="true"
                           data-msg-reqiured="enter email"

                           class="form-control" id="email" required=""/>

                </div>

                <div class="form-group">
                    <label for="password" >PASSWORD</label>

                    <input type="password" name="password"
                           data-rule-required="true"
                           data-msg-required="enter password"

                           class="form-control" id="password" required=""/>


                </div>
                <div class="form-group">
                    <label for="conpasssword" >CONFIRM PASSWORD</label>


                    <input type="password" name="conpassword"
                           data-rule-required="true"
                           data-rule-equalto="#password"
                           data-msg-equalto="password and confirm password not match"
                           data-msg-reqiured="enter confirm password"
                           class="form-control" id="conpassword" required=""/>

                </div>
                <div class="form-group">
                    <label for="mobileno" >Mobile Number</label>


                    <input type="text" name="mobileno"
                           data-rule-required="true"
                           data-rule-number="true"
                           data-msg-required="enter Mobile Number"

                           id="mobileno" class="form-control"/>
                </div>

                <div class="form-group">
                    <label for="type">TYPE</label>

                    <select name="type" id="type" class="form-control">
                    <option> select type</option>
                    <option value="Admin">ADMIN</option>
                    <option value="SUBADMIN">SUBADMIN</option>

                    </select>

                </div>

                <div class="form-group">

                    <input type="submit" value="Create Admin" class="btn btn-primary">
                    <?php
                    if (isset($_GET["msg"])) {
                        if ($_GET["msg"] == 0) {
                            echo "<div class='alert alert-danger'>please enter valid data</div>";
                        } else {
                            echo "<div class='alert alert-success'>data entered</div>";
                        }
                    }
                    ?>
                </div>


            </form>
        </div>
    </div>

</div>


<?php
include "footer.php";

?>
<script>
    $(document).ready(function () {
        $("#form1").validate();
    })
</script>
</body>
</html>