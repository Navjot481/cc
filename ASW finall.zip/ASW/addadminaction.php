<?php
include "connection.php";
$email = $_POST["email"];
$password = $_POST["password"];
$conpassword = $_POST["conpassword"];
$mobileno = $_POST["mobileno"];
$type = $_POST["type"];
if ($password != $conpassword) {
    echo "password and conpassword not match";
} else {
    $password = md5($password);
    $insertquery = "INSERT INTO `Admin` VALUES ('$email','$password','$mobileno','$type')";

    if (mysqli_query($con, $insertquery)) {
        header("location:addadmin.php?msg=1");
    } else {
        header("location:addadmin.php?msg=0");
    }
}

