<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php
    include_once "headerfiles.php";
    ?>
</head>
<body>
<?php
include_once "publicheader.php";
?>

<!-- Hero section -->
<section class="hero-section">
    <div class="hero-slider owl-carousel">
        <div class="hs-item set-bg" data-setbg="img/hero-slider/1.jpg">
            <div class="hs-text">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="hs-subtitle">Award Winning UNIVERSITY</div>
                            <h2 class="hs-title">An investment in knowledge pays the best interest.</h2>
                            <p class="hs-des">Education is not just about going to school and getting a degree. It's
                                about widening your<br> knowledge and absorbing the truth about life. Knowledge is
                                power.</p>
                            <div class="site-btn">GET STARTED</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="hs-item set-bg" data-setbg="img/hero-slider/2.jpg">
            <div class="hs-text">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="hs-subtitle">Award Winning UNIVERSITY</div>
                            <h2 class="hs-title">An investment in knowledge pays the best interest.</h2>
                            <p class="hs-des">Education is not just about going to school and getting a degree. It's
                                about widening your<br> knowledge and absorbing the truth about life. Knowledge is
                                power.</p>
                            <div class="site-btn">GET STARTED</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Hero section end -->
<br>
<br>
<div class="container pt-4">
    <h2 class="text-center">
        Welcome To ACADEMIC SUPPORT WEBSITE</h2>
</div>
<br>
<br>
<?php
include_once "footer.php";
?>
</body>
</html><?php
